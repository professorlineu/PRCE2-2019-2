#include <iostream>
#include<stdio.h>
#include "Desafio_3.h"
#include<iomanip>

using namespace std;

int main()
{
    Desafio_3 D1;

    double dAltura = 0;
    int i = 0;

    setlocale(LC_ALL, "");
    cout << setfill('0');

    D1.getMenIn();

    while (D1.geti() != 1)

    {
        do
        {
            cout << "\n_ _ _ _ _" << endl;
            cout << "\n Informe a altura de alcance necess�ria (em cent�metros): ";
            cin >> dAltura;
            D1.setAltura(dAltura);

            if (D1.getAltura() < 0)
            {
                D1.getMenErro();
            }

            else if (D1.getAltura() >= 0 && D1.getAltura() <= 30)
            {
                cout << "\n N�o h� a necessidade de escada para essa altura!" << endl;
                cout << " Altura do degrau: 30 cm." << endl;
                do
                {
                    D1.getMenRet();
                    cin >> i;
                    D1.seti(i);

                    if(D1.geti() == 1 )
                    {
                        cout << "\nObrigado pela prefer�ncia!" << endl;
                        cout << "\nVolte sempre!" << endl;

                        return 0;
                    }
                    else if (D1.geti()!= 1 && D1.geti()!= 0)
                    {
                        D1.getMenErro();
                    }

                }
                while (D1.geti()!= 0 && D1.geti()!= 1);
            }
        }
        while (D1.getAltura() <= 30);

        cout << "\n Voc� ir� precisar de uma escada de " << D1.getCalculo() << " degrau(s)" << endl;
        cout << " Altura do degrau: 30 cm." << endl;
        D1.getMenRet();
        cin >> i;
        D1.seti(i);
        if (D1.geti()!= 0 && D1.geti()!= 1)
        {
            D1.getMenErro();
        }
    }

    cout << "\n- - - - - - - - - - - - - - - -" << endl;
    cout << "\nObrigado pela prefer�ncia!" << endl;
    cout << "\nVolte sempre!" << endl;
    cout << "\n- - - - - - - - - - - - - - - -" << endl;

    return 0;

}

