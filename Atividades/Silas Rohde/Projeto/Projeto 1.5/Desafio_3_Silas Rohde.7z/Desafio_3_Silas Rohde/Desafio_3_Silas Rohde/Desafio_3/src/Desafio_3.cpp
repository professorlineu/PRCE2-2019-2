#include "Desafio_3.h"
#include <iostream>
#include <cmath>
using namespace std;

Desafio_3::Desafio_3()
{
    //ctor
    Altura = 0;
}

Desafio_3::~Desafio_3()
{
    //dtor
}

double Desafio_3::setAltura(int H)
{
    Altura = H;
}

int Desafio_3::seti(int I)
{
    i = I;
}

double Desafio_3::getAltura()
{
    return Altura;
}

double Desafio_3::getCalculo()
{
    return round((2 * Altura)/30);
}

int Desafio_3::geti()
{
    return i;
}

void Desafio_3::getMenIn()
{
    cout << "\n******************************************************************************" << endl;
    cout << "\n Bem-vindo a EscadaNorte!" << endl;
    cout << " Aqui voc� ir� encontrar a melhor escada para a sua necessidade!" << endl;
    cout << "\n******************************************************************************" << endl;
}

void Desafio_3::getMenRet()
{
    cout << "\n Gostaria de fazer uma nova consulta?" << endl;
    cout << " - Sim, digite 0 (Zero): " << endl;
    cout << " - N�o, digite 1 (Um): " << endl;
}

void Desafio_3::getMenErro()
{
    cout << "\n Valor incorreto!" << endl;
    cout << " Digite novamente!" << endl;
}
