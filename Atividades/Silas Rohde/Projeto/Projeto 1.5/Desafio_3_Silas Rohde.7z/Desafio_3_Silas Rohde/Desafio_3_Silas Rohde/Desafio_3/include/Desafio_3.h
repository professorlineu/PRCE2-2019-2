#ifndef DESAFIO_3_H
#define DESAFIO_3_H


class Desafio_3
{
public:
// construtor e destrutor

    Desafio_3();
    ~Desafio_3();

// m�todos setters

    double setAltura(int H);
    int seti (int I);



// m�todos getters

    double getAltura();
    int geti();
    double getCalculo();
    void getMenIn();
    void getMenRet();
    void getMenErro();


private:

// atributos

    double Altura;
    int i;
    double Calculo;

};

#endif // DESAFIO_3_H
