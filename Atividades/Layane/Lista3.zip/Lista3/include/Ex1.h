#ifndef Ex1_H
#define Ex1_H


class Ex1
{
public:
    Ex1();
    ~Ex1();
    void setHora(int);
    void setHora(int, int);
    void setHora(int, int, int);

    int getHora();
    int getMinuto();
    int getSegundo();
    void getHoraCompleta();

private:
    int Hora;
    int Minuto;
    int Segundo;
};

#endif // EX1_H
