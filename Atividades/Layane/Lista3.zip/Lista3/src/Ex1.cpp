#include "Ex1.h"
#include <iomanip>
#include <iostream>

using namespace std;

Ex1::Ex1()
{
    Hora=0;
    Minuto=0;
    Segundo=0;
}

Ex1::~Ex1()
{

}
void Ex1::setHora(int h)
{
    Hora = h;
}

void Ex1::setHora(int h, int m)
{
    Hora = h;
    Minuto = m;
}

void Ex1::setHora(int h, int m, int s)
{
    Hora = h;
    Minuto = m;
    Segundo = s;
}

int Ex1::getHora()
{
    return Hora;
}

int Ex1::getMinuto()
{
    return Minuto;
}

int Ex1::getSegundo()
{
    return Segundo;
}

void Ex1::getHoraCompleta()
{
    cout << setfill('0');
    cout << "Hor�rio 1: "
         << setw(2) << Ex1::getHora() << ":" << "00" << ":" << "00" << endl;

    cout << "Hor�rio 2: "
         << setw(2) << Ex1::getHora() << ":"
         << setw(2) << Ex1::getMinuto() << ":" << "00" << endl;

    cout << "Hor�rio 3: "
         << setw(2) << Ex1::getHora() << ":"
         << setw(2) << Ex1::getMinuto() << ":"
         << setw(2) << Ex1::getSegundo() << endl;
}
