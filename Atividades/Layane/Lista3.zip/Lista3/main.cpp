#include <iostream>
#include "Ex1.h"

using namespace std;

int h = 0;
int m = 0;
int s = 0;

int main()
{
    Ex1 H1;
    cout << "Informe a hora: ";
    cin >> h;
    if (h == 0)
    {
        H1.setHora(h);
        H1.getHoraCompleta();
        return 0;
    }

    cout << "Informe os minutos: ";
    cin >> m;

    if (m == 0)
    {
        H1.setHora(h,m);
        H1.getHoraCompleta();
        return 0;
    }

    cout << "Informe os segundos: ";
    cin >> s;

    H1.setHora(h,m,s);
    H1.getHoraCompleta();
    return 0;
}
