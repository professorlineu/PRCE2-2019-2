#ifndef FILMES_H
#define FILMES_H
#include <string>

using namespace std;

class Filmes
{
public:
    Filmes();
    ~Filmes();

    void setID1 (int);
    void setNome1 (string);
    void setAno1 (int);
    void setID2 (int);
    void setNome2 (string);
    void setAno2 (int);

    void getID1 (int);
    void getNome1 (string);
    void getAno1 (int);
    void getID2 (int);
    void getNome2 (string);
    void getAno2 (int);




private:
    int ID1;
    int ID2;
    int Ano1;
    int Ano2;
    string Nome1;
    string Nome2;
};

#endif // FILMES_H
