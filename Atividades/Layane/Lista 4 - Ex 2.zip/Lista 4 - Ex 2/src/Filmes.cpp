#include "Filmes.h"
#include <iostream>
#include <string>
#include <iomanip>

using namespace std;

Filmes::Filmes()
{
    int ID1 = 0;
    int ID2 = 0;
    int Ano1 = 0;
    int Ano2 = 0;
    string Nome1 = " ";
    string Nome2 = " ";

}

Filmes::~Filmes()
{

}
    void Filmes::setID1 (int id1)
    {
        ID1 = id1;
    }
    void Filmes::setID2(int id2)
    {
        ID2 = id2;
    }
    void Filmes::setNome1(string n1)
    {
        Nome1 = n1;
    }
    void Filmes::setNome2(string n2)
    {
        Nome2 = n2;
    }
    void Filmes::setAno1(int a1)
    {
        Ano1 = a1;
    }
    void Filmes::setAno2(int a2)
    {
        Ano2 = a2;
    }
