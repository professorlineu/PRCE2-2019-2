#include <iostream>
#include "Filmes.h"
#include<string>
#include <iomanip>
#include <locale.h>
#include <cstdlib>


using namespace std;

int main()
{
    Filmes F1;

    int ID1 = 0;
    int ID2 = 0;
    int Ano1 = 0;
    int Ano2 = 0;
    string Nome1 = " ";
    string Nome2 = " ";

    setlocale(LC_ALL,"");
    system("color F1");

    cout<<"1� Filme - Informe o ID: "<<endl;
    cin>>ID1;
    F1.setID1(ID1);

    cin.ignore();
    cout<<"Informe o nome do filme: "<<endl;
    getline(cin, Nome1);
    F1.setNome1(Nome1);

    cout<<"Informe o ano do filme: "<<endl;
    cin>>Ano1;
    F1.setAno1(Ano1);

     cout<<"2� Filme - Informe o ID: "<<endl;
    cin>>ID2;
    F1.setID2(ID2);

    cin.ignore();
    cout<<"Informe o nome do filme: "<<endl;
    getline(cin, Nome2);
    F1.setNome2(Nome2);

    cout<<"Informe o ano do filme: "<<endl;
    cin>>Ano2;
    F1.setAno2(Ano2);

    if (Ano1 < 2019)
    {
        cout<<"O 1� filme foi lan�ado antes deste ano e ";
    }
    else if (Ano1 = 2019)
    {
        cout<<"O 1� filme foi lan�ado neste ano e ";
    }
    if (Ano2 < 2019)
    {
        cout<<"o 2� filme foi lan�ado antes deste ano";
    }
    else if (Ano2 = 2019)
    {
        cout<<"o 2� filme foi lan�ado neste ano";
    }

   return 0;
}
