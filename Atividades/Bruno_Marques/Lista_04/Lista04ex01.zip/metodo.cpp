/**********************************************************
- Autor:     BRUNO MARQUES MARTINS
- Descrição: definição dos metodos da classe
**********************************************************/
#include <iostream>
#include <locale.h>
#include <cstdlib>
#include <string>
#include "classe.h"
using namespace std;

		void cliente::setID(int d, int i)
			{	
				d=i;
				ID=d+100;
			}
		void cliente::setNome(string n)
			{
				Nome=n;
			}

		void cliente::setIdade(int ida)
			{
				Idade=ida;
			}

		void cliente::setEmail(string em)
			{	
				Email=em;
			}
		
		void cliente::setCidade(string c)
			{
				Cidade=c;
			}

		string cliente::getNome()
			{
			return Nome;
			}

		int cliente::getID()
			{
				return ID;
			}
		int cliente::getIdade()
			{
			return Idade;
			}

		string cliente::getEmail()
			{
			return Email;
			}
		string cliente::getCidade()
			{
			return Cidade;
			}