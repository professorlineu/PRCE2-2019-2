/**********************************************************
- Autor:     BRUNO MARQUES MARTINS
- Descrição: EXERCICIO LISTA 04 - ORIENTAÇÃO A OBJETOS
**********************************************************/
#include <iostream>
#include <locale.h>
#include <cstdlib>
#include <string>
#include "classe.h"
using namespace std;

//Variaveis
string sNome;
string sCidade;
string sEmail;
int iIdade;
int iID;

int main()
{
cout<<"---INICIO---"<<endl;
cliente c[5];

for (int i=0; i<5;i++)
	{
cout<<"Digite o nome do Cliente "<<": "<<endl;
cin>>sNome;
c[i].setNome(sNome);
c[i].setID(iID,i);
cout<<"Digite o email do Cliente "<<endl;
cin>>sEmail;
c[i].setEmail(sEmail);
cout<<"Digite a idade do Cliente "<<endl;
cin>>iIdade;
c[i].setIdade(iIdade);
cout<<"Digite a cidade do Cliente "<<endl;
cin>>sCidade;
c[i].setCidade(sCidade);
cout<<"------------------------------"<<endl<<endl;
	}

for (int i=0; i<5;i++)
	{
cout<<"DADOS DO CLIENTE:"<<endl<<endl;
cout<<"ID : "<<c[i].getID()<<endl;	
cout<<"Nome: "<<c[i].getNome()<<endl;
cout<<"Idade: "<<c[i].getIdade()<<endl;
cout<<"Email: "<<c[i].getEmail()<<endl;
cout<<"Cidade: "<<c[i].getCidade()<<endl;
cout<<"------------------------------"<<endl<<endl;
	}
}
