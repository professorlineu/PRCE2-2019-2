/**********************************************************
- Autor:     BRUNO MARQUES MARTINS
- Descrição: declaração de propriedades da classe
**********************************************************/
#include <iostream>
#include <locale.h>
#include <cstdlib>
#include <string>
using namespace std;

class cliente
{
	public:
void setNome(string n);
void setIdade(int ida);
void setEmail(string em);
void setCidade(string c);
void setID(int d, int i);

string getNome();
int getIdade();
int getID();
string getEmail();
string getCidade();

	private:
int ID;
int Idade;
string Nome;
string Email;
string Cidade;
};