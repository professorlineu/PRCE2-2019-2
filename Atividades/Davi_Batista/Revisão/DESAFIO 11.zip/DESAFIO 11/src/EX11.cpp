#include "EX11.h"
#include <iostream>
#include <string>

using namespace std;

EX11::EX11()
{
    iCont = 10;

     for(int y=0; y < 10; y++)
    {
        iVetorPrin[y] = 0;
    }


}

void EX11 :: getVetor()
{
    cout << endl << "Valor do Vetor: ";
    for(int y= iCont; y < 10; y++)
    {
        cout << iVetorPrin[y] << "; ";

    }
}

void EX11 :: getCaracter()
{
   int y = 0;
   cout << endl << "Escolha a posi��o que gostaria de ver (0 a 9):";
   cin >> y;
   if(y >= 0 && y < 10 - iCont)
   {
       cout << endl << "Valor escolhido: " << iVetorPrin[iCont+y];
   }
   else
   {
       cout << endl << "POSI��O INVALIDA, FAVOR REFAZER OPERA��O";
   }

}

void EX11 :: setOrdemVetor()
{
    int y = 0;
    int iCont2 = 1;
    while (iCont2 != 0)
    {
        iCont2 = 0;
        for(int x = 9; x > iCont; x--)
        {
            if(iVetorPrin[x] < iVetorPrin[x-1])
            {
                y = iVetorPrin[x-1] ;
                iVetorPrin[x-1] = iVetorPrin[x];
                iVetorPrin[x] = y;
                iCont2++;
            }
        }
    }
}
void EX11 :: setVetor()
{
    double u = 0;
    if(iCont > 0)
    {
    cout << endl << "Insira o valor desejado: ";
    cin >> u;
    for(int y = 9; y >= 0; y--)
    {
        if(iVetorPrin[y] ==0)
        {
            iVetorPrin[y] = u;
            y = -1;
        }

    }
    iCont--;
    setOrdemVetor();
    }
    else
    {
        cout << endl << "Vetor Cheio!!!";
    }
}
void EX11 :: setDelete()
{
    int iValor = 0;
    cout << endl << "Insira o valor que deseja deletar: ";
    cin >> iValor;
    for(int y = iCont; y < 10; y++)
    {
        if(iVetorPrin[y] == iValor)
        {
            iVetorPrin[y] = 0;
            for(int x = y; x > 0; x--)
            {
                iVetorPrin[x] = iVetorPrin[x-1];
            }
            iCont++;
            setOrdemVetor();
        }
    }
}
void EX11 :: setReset()
{
     iCont = 110;

     for(int y=0; y < 10; y++)
    {
        iVetorPrin[y] = 0;
    }
}
