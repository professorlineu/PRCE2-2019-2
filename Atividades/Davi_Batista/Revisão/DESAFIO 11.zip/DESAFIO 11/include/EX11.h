#ifndef EX11_H
#define EX11_H


class EX11
{
    public:

    EX11();
    void getVetor();
    void getCaracter();
    void setVetor();
    void setOrdemVetor();
    void setReset();
    void setDelete();





    private:

    double iVetorPrin[10];
    int iCont;


};

#endif // EX11_H
