#include "EX11.h"
#include <iostream>
#include <string>

using namespace std;

int main()
{
    float y1 = 0;
    int y = 0;
    int x = 0;

    EX11 V1;


while(x == 0)
{

    cout << endl << "=============================================================================" ;
    cout << endl << "DEFINA A OPERA��O QUE DESEJA REALIZAR" ;
    cout << endl << "1- INCLUIR UM NUMERO NO VETOR    2- CONSULTAR TODOS OS NUMEROS DO VETOR";
    cout << endl << "3- CONSULTAR UM NUMERO DO VETOR  4- EXCLUIR UM NUMERO NO VETOR";
    cout << endl << "5- ESVAZIAR O VETOR              6- SAIR" << endl << endl;

    cin >> y1;
    if(0 < y1 && y1 < 7)
    {
    y = y1;
        switch(y)
        {
        case 1:
            V1.setVetor();
            break;

        case 2:
            V1.getVetor();
            break;

        case 3:
            V1.getCaracter();
            break;

        case 4:
            V1.setDelete();
            break;

        case 5:
            V1.setReset();
            break;

        case 6:
            x = 1;
            break;

        }
    }
    else
    {
        cout << endl << "VALOR IMPROPRIO, FAVOR REPETIR PROCESSO.";
    }



}

    return 0;
}
