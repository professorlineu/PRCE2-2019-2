#include <iostream>
#include <ctype.h>
#include <cstdlib>

using namespace std;

int main() 
{
int cont, num, alt, maior, menor, numMaior, numMenor;

for (cont = 1; cont <= 5; cont++)
{
 cout << "Entre com um numero:" << endl;
 cin >> num;
 cout<< "E a altura em cm:" << endl;
 cin >> alt;

 if (cont == 1 )
 {
   maior = alt;
   numMaior = num;
   menor = alt;
   numMenor = num;
 } 
 else if (alt > maior)
{
 maior = alt;
 numMaior = num;
}
else if (alt < menor)
{
  menor = alt;
  numMenor = num;
}

}

cout << "Maior altura e:" << maior << numMaior;
 return 0;
}