#include "Cliente.h"
#include <string>

Cliente::Cliente()
{
    int ID = 0;
    int Idade = 0;
    string Nome = "";
    string Email = "";
    string Cidade = "";
}

Cliente::~Cliente()
{
   }
void Cliente::setID(int id)
{
    ID = id;
}

void Cliente::setNome(string n)
{
    Nome = n;
}

void Cliente::setIdade(int i)
{
    Idade = i;
}

void Cliente::setEmail(string e)
{
    Email = e;
}

void Cliente::setCidade(string c)
{
    Cidade = c;
}


int Cliente::getID()
{
    return ID;
}

string Cliente::getNome()
{
    return Nome;
}

int Cliente::getIdade()
{
    return Idade;
}

string Cliente::getEmail()
{
    return Email;
}

string Cliente::getCidade()
{
    return Cidade;
}
