#include <iostream>
#include "Cliente.h"

using namespace std;

int ID = 0;
int Idade = 0;
string Nome = "";
string Email = "";
string Cidade = "";

int main()
{
    Cliente C1;

    cout << "Informe o ID ";
    cin >> ID;

    C1.setID(ID);

    cin.ignore();
    cout << "Informe o nome: ";
    getline (cin, Nome);
    C1.setNome(Nome);


    cout << "Informe a idade ";
    cin >> Idade;
    C1.setIdade(Idade);


    cout << "Informe o email: ";
    cin >> Email;
    C1.setEmail(Email);

    cin.ignore();
    cout << "Informe a cidade: ";
    getline(cin, Cidade);
    C1.setCidade(Cidade);


    cout << "Dados do cliente: " << endl;

    cout << "ID: " << C1.getID() << endl;
    cout << "Nome: " << C1.getNome() << endl;
    cout << "Idade: " << C1.getIdade() << endl;
    cout << "Email: " << C1.getEmail() << endl;
    cout << "Cidade: " << C1.getCidade() << endl;
    return 0;
}

