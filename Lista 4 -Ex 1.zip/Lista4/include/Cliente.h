#ifndef CLIENTE_H
#define CLIENTE_H
#include<string.h>
#include<iostream>
#include<stdio.h>

using namespace std;
class Cliente
{
    public:
        Cliente();
     ~Cliente();
    void setID (int);
    void setNome (string);
    void setIdade (int);
    void setEmail (string);
    void setCidade (string);

    int getID();
    int getIdade();
    string getEmail();
    string getNome();
    string getCidade();

    private:
        int ID;
        int Idade;
        string Nome;
        string Email;
        string Cidade;
};

#endif // CLIENTE_H
