#include <iostream>
#include <ctype.h>
#include <cstdlib>

using namespace std;

int main() 
{
  int n1, n2, n3, media;

  cout << "Digite sua nota 1 (0 a 100):" << endl;
  cin >> n1;

  cout << "Digite sua nota 2 (0 a 100):" << endl;
  cin >> n2;

  cout << "Digite sua nota 3 (0 a 100):" << endl;
  cin >> n3;

  media = (n1 + n2 + n3)/3;
   
  cout << "sua media e: " << media;
  

  if (media < 60 && media > 0)
  {
   cout << "\nreprovado" << endl; 
  }
  if (media >=60 && media <= 100 )
  {
   cout << "\naprovado" << endl; 
  }
 
  

 return 0;
}