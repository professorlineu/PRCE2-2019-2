#ifndef CONTABANCARIA_H
#define CONTABANCARIA_H
#include <string>


class ContaBancaria
{
    public:
        ContaBancaria();
        ~ContaBancaria();

        void setSaldo(double);
        void setCredito(double);
        void setDebito(double);

        double getSaldo();
        double getCredito();
        double getDebito();


    private:

        double Saldo;
        double Credito;
        double Debito;

};

#endif // CONTABANCARIA_H
