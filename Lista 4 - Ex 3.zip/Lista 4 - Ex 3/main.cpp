#include <iostream>
#include "ContaBancaria.h"
#include<string>
#include <iomanip>
#include <locale.h>
#include <cstdlib>

using namespace std;

int main()
{
    ContaBancaria CB;

    double Saldo = 0;
    double Credito = 0;
    double Debito = 0;
    int i = 0;
    int opt = 0;

    setlocale(LC_ALL,"");
    system("color F1");

    cout<<"Informe o saldo da conta: R$ ";
    cin>>Saldo;
    CB.setSaldo(Saldo);

    cout<<" Op��es "<<endl;
    cout<<"1 - Cr�dito"<<endl;
    cout<<"2 - D�bito"<<endl;
    cin>>opt;

   switch (opt)
    {
    case 1:
        cout<<"Insira o valor a depositar"<<endl;
        cin>>Credito;
        CB.setCredito(Credito);
        CB.setSaldo(Saldo + Credito);
        break;
    case 2:
        cout<<"Insira o valor a retirar"<<endl;
        cin>>Debito;
        CB.setDebito(Debito);
        CB.setSaldo(Saldo - Debito);

        break;
    default: 0;
    }

    cout<<"O saldo atual � de R$"<<CB.getSaldo();


    return 0;
}
