#include "ContaBancaria.h"
#include <iostream>
#include <string>
#include <iomanip>
#include <locale.h>

using namespace std;
ContaBancaria::ContaBancaria()
{
    double Saldo = 0;
    Credito = 0;
    Debito = 0;

}

ContaBancaria::~ContaBancaria()
{
    //dtor
}
    void ContaBancaria::setCredito (double c)
    {
        Credito = c + Saldo;
        }
    void ContaBancaria::setDebito (double d)
    {
       if(d < Saldo )
    {
        Debito = Saldo - d;
    }
    if(d >= Saldo)
    {
       cout<<"Saldo insuficiente para a opera��o"<<endl;
        }
    }
    void ContaBancaria::setSaldo (double s)
    {
        Saldo = s;
    }
    double ContaBancaria::getCredito ()
    {
        return Credito;
    }
    double ContaBancaria::getDebito()
    {
       return Debito;
    }
    double ContaBancaria::getSaldo ()
    {
        return Saldo;
    }
