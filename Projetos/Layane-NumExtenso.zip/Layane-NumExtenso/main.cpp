#include "ENTRADA.H"
#include <cstdlib>
#include <iostream>
#include <locale.h>
#include <stdio.h>
#include <string>

using namespace std;

int main()
{
    Entrada e1;

    setlocale(LC_ALL,"");
    system("color F1");

    e1.setiNum();
    e1.setVetor();
    e1.setDm();
    e1.setMil();
    e1.setCent();
    e1.setDez();
    e1.setUn();
    return 0;
}
