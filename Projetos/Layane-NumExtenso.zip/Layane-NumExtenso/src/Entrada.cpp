#include "Entrada.h"
#include "ENTRADA.H"
#include <cstdlib>
#include <iostream>
#include <locale.h>
#include <stdio.h>

using namespace std;

Entrada::Entrada()
{
    iNum = 0;
    for (int i = 0; i<5; i++)
    {
        Vetor[i]=0;
    }
}

Entrada::~Entrada()
{
    //dtor
}

void Entrada::setiNum()
{
    do
    {
        cout<<"Informe um n�mero de 0 a 10000"<<endl;
        cin>>iNum;
    }
    while((iNum <= 0)||(iNum > 10000));
}

void Entrada::setVetor()
{
    for (int i = 0; i < 5; i++)
    {
        if (iNum >= 1)
        {
            Vetor [i] = iNum % 10;
            iNum = iNum/10;
        }
    }
}

void Entrada::setDm()
{
    switch (Vetor[4])
    {
    case 1:
        cout<<"Dez mil ";
        break;
    }
}
void Entrada::setMil()
{
    switch (Vetor[3])
    {
    case 1:
        cout<<"Mil ";
        break;
    case 2:
        if (Vetor [0]==0 && Vetor[1]==0 && Vetor [2]==0)
        {
            cout<<"Dois mil ";
        }
        else
        {
            cout<<"Dois mil e ";
        }
        break;
    case 3:
        if (Vetor [0]==0 && Vetor[1]==0 && Vetor [2]==0)
        {
            cout<<"Tr�s mil ";
        }
        else
        {
            cout<<"Tr�s mil e ";
        }
        break;
    case 4:
        if (Vetor [0]==0 && Vetor[1]==0 && Vetor [2]==0)
        {
            cout<<"Quatro mil ";
        }
        else
        {
            cout<<"Quatro mil e ";
        }
        break;
    case 5:
        if (Vetor [0]==0 && Vetor[1]==0 && Vetor [2]==0)
        {
            cout<<"Cinco mil ";
        }
        else
        {
            cout<<"Cinco mil e ";
        }
        break;
    case 6:
        if (Vetor [0]==0 && Vetor[1]==0 && Vetor [2]==0)
        {
            cout<<"Seis mil ";
        }
        else
        {
            cout<<"Seis mil e ";
        }
        break;
    case 7:
        if (Vetor [0]==0 && Vetor[1]==0 && Vetor [2]==0)
        {
            cout<<"Sete mil ";
        }
        else
        {
            cout<<"Sete mil e ";
        }
        break;
    case 8:
        if (Vetor [0]==0 && Vetor[1]==0 && Vetor [2]==0)
        {
            cout<<"Oito mil ";
        }
        else
        {
            cout<<"Oito mil e ";
        }
        break;
    case 9:
        if (Vetor [0]==0 && Vetor[1]==0 && Vetor [2]==0)
        {
            cout<<"Nove mil ";
        }
        else
        {
            cout<<"Nove mil e ";
        }
        break;
    }

}
void Entrada::setCent()
{
    switch (Vetor[2])
    {
    case 1:
        if (Vetor [0]==0 && Vetor[1]==0)
        {
            cout<<"Cem ";
        }
        else
        {
            cout<<"Cento e ";
        }
        break;
    case 2:
        if (Vetor [0]==0 && Vetor[1]==0)
        {
            cout<<"Duzentos";
        }
        else
        {
            cout<<"Duzentos e ";
        }
        break;
    case 3:
        if (Vetor [0]==0 && Vetor[1]==0)
        {
            cout<<"Trezentos";
        }
        else
        {
            cout<<"Trezentos e ";
        }
        break;
    case 4:
        if (Vetor [0]==0 && Vetor[1]==0)
        {
            cout<<"Quatrocentos ";
        }
        else
        {
            cout<<"Quatrocentos e ";
        }
        break;
    case 5:
        if (Vetor [0]==0 && Vetor[1]==0)
        {
            cout<<"Quinhentos";
        }
        else
        {
            cout<<"Quinhentos e ";
        }
        break;
    case 6:
        if (Vetor [0]==0 && Vetor[1]==0)
        {
            cout<<"Seiscentos ";
        }
        else
        {
            cout<<"Seiscentos e ";
        }
        break;
    case 7:
        if (Vetor [0]==0 && Vetor[1]==0)
        {
            cout<<"Setecentos ";
        }
        else
        {
            cout<<"Setecentos e ";
        }
        break;
    case 8:
        if (Vetor [0]==0 && Vetor[1]==0)
        {
            cout<<"Oitocentos";
        }
        else
        {
            cout<<"Oitocentos e ";
        }
        break;
    case 9:
        if (Vetor [0]==0 && Vetor[1]==0)
        {
            cout<<"Novecentos ";
        }
        else
        {
            cout<<"Novecentos e ";
        }
        break;
    }
}
void Entrada::setDez()
{
    switch (Vetor[1])
    {
    case 1:
        switch (Vetor[0])
        {
        case 0:
            cout<<"Dez ";
            break;
        case 1:
            cout<<"Onze ";
            break;
        case 2:
            cout<<"Doze";
            break;
        case 3:
            cout<<"Treze";
            break;
        case 4:
            cout<<"Quatorze";
            break;
        case 5:
            cout<<"Quinze";
            break;
        case 6:
            cout<<"Dezesseis";
            break;
        case 7:
            cout<<"Dezessete";
            break;
        case 8:
            cout<<"Dezoito";
            break;
        case 9:
            cout<<"Dezenove";
            break;
        }
        break;
    case 2:
        if (Vetor [0]==0)
        {
            cout<<"Vinte";
        }
        else
        {
            cout<<"Vinte e ";
        }
        break;
    case 3:
        if (Vetor [0]==0)
        {
            cout<<"Trinta";
        }
        else
        {
            cout<<"Trinta e ";
        }
        break;
    case 4:
        if (Vetor [0]==0)
        {
            cout<<"Quarenta ";
        }
        else
        {
            cout<<"Quarenta e ";
        }
        break;
    case 5:
        if (Vetor [0]==0)
        {
            cout<<"Cinquenta";
        }
        else
        {
            cout<<"Cinquenta e ";
        }
        break;
    case 6:
        if (Vetor [0]==0)
        {
            cout<<"Sessenta";
        }
        else
        {
            cout<<"Sessenta e ";
        }
        break;
    case 7:
        if (Vetor [0]==0)
        {
            cout<<"Setenta ";
        }
        else
        {
            cout<<"Setenta e ";
        }
        break;
    case 8:
        if (Vetor [0]==0)
        {
            cout<<"Oitenta ";
        }
        else
        {
            cout<<"Oitenta e ";
        }
        break;
    case 9:
        if (Vetor [0]==0)
        {
            cout<<"Noventa ";
        }
        else
        {
            cout<<"Noventa e ";
        }
        break;
    }
}
void Entrada::setUn()
{
    if (Vetor[1] == 1)
    {
    }
    else
    {
        switch (Vetor [0])
        {
        case 1:
            cout<<"Um ";
            break;
        case 2:
            cout<<"Dois";
            break;
        case 3:
            cout<<"Tr�s";
            break;
        case 4:
            cout<<"Quatro ";
            break;
        case 5:
            cout<<"Cinco ";
            break;
        case 6:
            cout<<"Seis ";
            break;
        case 7:
            cout<<"Sete ";
            break;
        case 8:
            cout<<"Oito ";
            break;
        case 9:
            cout<<"Nove ";
            break;
        }
    }
}
