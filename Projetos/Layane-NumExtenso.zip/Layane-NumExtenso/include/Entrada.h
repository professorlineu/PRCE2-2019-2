#ifndef ENTRADA_H
#define ENTRADA_H
#include <cstdlib>
#include<string>

using namespace std;

class Entrada
{
    public:
        Entrada();
        virtual ~Entrada();

        void setiNum();
        void setVetor ();
        void setDm();
        void setMil();
        void setCent();
        void setDez();
        void setUn();

    private:
        int Vetor [5];
        int iNum;
};

#endif // HORARIO_H
